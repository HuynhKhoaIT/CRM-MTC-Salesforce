# Đồng bộ CSS + logo từ LWC sang thư mục preview.
# Chạy lại mỗi khi sửa qcRequestWizard.css hoặc logos.js:
#   powershell -ExecutionPolicy Bypass -File preview\build-preview.ps1

$ErrorActionPreference = 'Stop'
$root   = Split-Path -Parent $PSScriptRoot
$lwc    = Join-Path $root 'force-app\main\default\lwc\qcRequestWizard'
$assets = Join-Path $PSScriptRoot 'assets'

if (-not (Test-Path $assets)) { New-Item -ItemType Directory -Path $assets | Out-Null }

# 1) CSS của component -> dùng nguyên xi
Copy-Item (Join-Path $lwc 'qcRequestWizard.css') (Join-Path $assets 'component.css') -Force

# 2) logos.js là ES module; chuyển thành script thường cho trang preview
$logos = Get-Content (Join-Path $lwc 'logos.js') -Raw -Encoding UTF8
$logos = $logos -replace 'export\s+const\s+', 'var '
Set-Content -Path (Join-Path $assets 'logos.js') -Value $logos -Encoding UTF8

Write-Output "Đã cập nhật preview\assets\component.css và preview\assets\logos.js"
